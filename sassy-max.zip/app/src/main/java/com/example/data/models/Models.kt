package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "Guest Max",
    val age: Int = 22,
    val gender: String = "Male", // "Male", "Female", "Other"
    val isLoggedIn: Boolean = false,
    val loginType: String = "Guest", // "Guest", "Google", "Phone"
    val coachPersonality: String = "Sassy", // "Sassy", "Brutal", "Friendly"
    val photoUri: String? = null
)

@Entity(tableName = "chat_message")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user", "coach"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "analysis_result")
data class AnalysisResult(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val overallScore: Double,
    val imagePath: String?, // Saved photo URI or path
    val potential: Int,
    val facialBalance: Int,
    val skin: Int,
    val jawline: Int,
    val cheekbones: Int,
    val hair: Int,
    val nose: Int,
    val eyes: Int,
    val lips: Int,
    val detailsJson: String // Stringified JSON containing "why" and "fixes" for each category
)

@Entity(tableName = "habit")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isCompletedToday: Boolean = false,
    val streakCount: Int = 0,
    val category: String = "Face" // "Skin", "Face", "Hair", "Lifestyle"
)

@Entity(tableName = "progress_history")
data class ProgressPoint(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val overallScore: Double
)
