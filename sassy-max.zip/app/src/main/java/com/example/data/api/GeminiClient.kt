package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

// --- Gemini API Models ---

data class InlineData(
    val mimeType: String,
    val data: String
)

data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

data class Content(
    val parts: List<Part>
)

data class ResponseFormatText(
    val mimeType: String,
    val schema: Map<String, Any>? = null
)

data class ResponseFormat(
    val text: ResponseFormatText? = null
)

data class GenerationConfig(
    val responseFormat: ResponseFormat? = null,
    val temperature: Float? = null
)

data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

// Simplified response structure to parse via Moshi
data class GeminiPartResponse(val text: String?)
data class GeminiContentResponse(val parts: List<GeminiPartResponse>?)
data class GeminiCandidate(val content: GeminiContentResponse?)
data class GeminiResponse(val candidates: List<GeminiCandidate>?)

// --- Sassy Max Look Analysis Result Model ---
data class SassyAnalysisResult(
    val overallScore: Double,
    val verdictText: String,
    val potential: Int,
    val facialBalance: Int,
    val skin: Int,
    val jawline: Int,
    val cheekbones: Int,
    val hair: Int,
    val nose: Int,
    val eyes: Int,
    val lips: Int,
    val explanation: Map<String, MetricExplanation>
)

data class MetricExplanation(
    val why: String,
    val fixes: List<String>
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): ResponseBody
}

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    // Helper to convert Bitmap to Base64 jpeg string
    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeLooks(bitmap: Bitmap): SassyAnalysisResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY") {
            Log.w(TAG, "API Key is empty or placeholder! Running simulated look analysis.")
            return@withContext getSimulatedAnalysis()
        }

        val base64Image = bitmap.toBase64()

        val systemPrompt = """
            You are "Sassy Max", a bold, high-fidelity AI aesthetics expert. Analyze the uploaded face photo and provide an objective style and looks assessment. 
            Be encouraging but stylish, bold, and sassy. Never use slurs, comparison to real famous people, or demean the user.
            You must output the response in a structured JSON schema exactly.
            
            Determine:
            1. overallScore (a floating point number between 0.0 and 10.0, e.g. 8.6).
            2. verdictText based on score tier:
               - 9.0 to 10.0: "Exceptional 🔥"
               - 7.0 to 8.9: "Attractive 😍"
               - 5.0 to 6.9: "Solid ⚡"
               - Below 5.0: "Room to Grow 🌱"
            3. Numeric scores (integer 0-100) and structured comments for 9 metrics:
               - potential
               - facialBalance
               - skin
               - jawline
               - cheekbones
               - hair
               - nose
               - eyes
               - lips
            
            For each metric, provide:
            - why: a single descriptive sentence detailing visible traits (e.g. "Excellent angularity and bone prominence").
            - fixes: a JSON list of 2-3 concrete actionable improvements (e.g., "Mewing daily", "Moisturizing with SPF 30").
            
            Format your final response as a single, valid JSON object matching this schema:
            {
               "overallScore": 8.6,
               "verdictText": "Attractive 😍",
               "potential": 90,
               "facialBalance": 80,
               "skin": 75,
               "jawline": 80,
               "cheekbones": 60,
               "hair": 90,
               "nose": 70,
               "eyes": 90,
               "lips": 65,
               "explanation": {
                  "potential": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "facialBalance": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "skin": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "jawline": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "cheekbones": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "hair": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "nose": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "eyes": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] },
                  "lips": { "why": "Why details", "fixes": ["Fix 1", "Fix 2"] }
               }
            }
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = "Analyze my looks and return JSON response matching the spec."),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseFormat = ResponseFormat(
                    text = ResponseFormatText(mimeType = "application/json")
                ),
                temperature = 0.4f
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
        )

        try {
            val responseBody = apiService.generateContent(apiKey, request)
            val jsonString = responseBody.string()
            Log.d(TAG, "Raw Gemini Response: $jsonString")

            // Parse text content from Gemini's JSON envelope manually or via light map parse
            val parsedResult = parseGeminiResponseText(jsonString)
            if (parsedResult != null) {
                return@withContext parsedResult
            } else {
                Log.w(TAG, "Failed to parse Gemini response text. Using simulation.")
                return@withContext getSimulatedAnalysis()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini Analysis Error: ${e.message}", e)
            return@withContext getSimulatedAnalysis()
        }
    }

    private fun parseGeminiResponseText(responseBodyString: String): SassyAnalysisResult? {
        try {
            // Sift through the outer response JSON envelope
            val responseMap = moshi.adapter(Map::class.java).fromJson(responseBodyString) ?: return null
            val candidates = responseMap["candidates"] as? List<*> ?: return null
            val firstCandidate = candidates.firstOrNull() as? Map<*, *> ?: return null
            val content = firstCandidate["content"] as? Map<*, *> ?: return null
            val parts = content["parts"] as? List<*> ?: return null
            val firstPart = parts.firstOrNull() as? Map<*, *> ?: return null
            val textContent = firstPart["text"] as? String ?: return null

            Log.d(TAG, "Parsed Nested textContent: $textContent")

            // Parse actual SassyAnalysisResult JSON inside textContent
            val sassyAdapter = moshi.adapter(SassyAnalysisResult::class.java)
            return sassyAdapter.fromJson(textContent)
        } catch (e: Exception) {
            Log.e(TAG, "Exception parsing Gemini textContent JSON: ${e.message}")
            // Let's try parsing directly if Gemini returned the schema at the root due to system prompt format
            try {
                return moshi.adapter(SassyAnalysisResult::class.java).fromJson(responseBodyString)
            } catch (inner: Exception) {
                Log.e(TAG, "Inner parsing failed too: ${inner.message}")
            }
        }
        return null
    }

    // High quality simulation for offline or API key missing
    fun getSimulatedAnalysis(): SassyAnalysisResult {
        val score = (7.5 + (Math.random() * 2.0)) // Realistic aesthetic scores
        val formattedScore = Math.round(score * 10.0) / 10.0
        val potentialVal = 92
        val facialBalanceVal = 82
        val skinVal = 78
        val jawlineVal = 80
        val cheekbonesVal = 65
        val hairVal = 91
        val noseVal = 72
        val eyesVal = 88
        val lipsVal = 74

        val explanations = mapOf(
            "potential" to MetricExplanation(
                "Incredible basic bone layout with outstanding alignment potential.",
                listOf("Keep body fat under 12% to reveal structure", "Perform posture workouts daily")
            ),
            "facialBalance" to MetricExplanation(
                "Symmetrical side profile and very strong facial depth ratios.",
                listOf("Focus on chewing tough foods evenly", "Check tongue posture regularly")
            ),
            "skin" to MetricExplanation(
                "Clean complexion but shows minor dehydration or under-eye puffiness.",
                listOf("Apply Salicylic acid exfoliant weekly", "Use daily SPF 50 moisturizer", "Drink 3.5L of water daily")
            ),
            "jawline" to MetricExplanation(
                "Defined mandibular angle with great masculine/feminine contour.",
                listOf("Start mewing immediately", "Reduce overall sodium intake to reduce face swelling")
            ),
            "cheekbones" to MetricExplanation(
                "Slightly hollow cheeks starting to show high malar prominence.",
                listOf("Do facial exercises to tone cheeks", "Avoid high carb bloating before sleep")
            ),
            "hair" to MetricExplanation(
                "Voluminous locks with a clean, flattering hairline and texture.",
                listOf("Use caffeine or rosemary oil weekly", "Wash hair with sulfate-free shampoo")
            ),
            "nose" to MetricExplanation(
                "Straight nasal bridge that fits well within the facial golden ratio.",
                listOf("Avoid mouth breathing to prevent narrow palate", "Focus on skincare around nasal pores")
            ),
            "eyes" to MetricExplanation(
                "Positive canthal tilt with clean horizontal eye spacing.",
                listOf("Use cold compress for under-eye bags", "Maintain consistent 8h sleep cycles")
            ),
            "lips" to MetricExplanation(
                "Nicely proportioned philtrum and clear vermillion border.",
                listOf("Exfoliate with sugar-honey scrub twice a week", "Use a nourishing beeswax lip balm")
            )
        )

        return SassyAnalysisResult(
            overallScore = formattedScore,
            verdictText = "Attractive 😍",
            potential = potentialVal,
            facialBalance = facialBalanceVal,
            skin = skinVal,
            jawline = jawlineVal,
            cheekbones = cheekbonesVal,
            hair = hairVal,
            nose = noseVal,
            eyes = eyesVal,
            lips = lipsVal,
            explanation = explanations
        )
    }

    // Call Sassy Sassy Coach chat response from Gemini REST API
    suspend fun getSassyCoachResponse(chatHistory: List<com.example.data.models.ChatMessage>, personality: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY") {
            Log.w(TAG, "API Key is missing for Chat. Fallback to sassy responses.")
            return@withContext getSimulatedSassyResponse(chatHistory.lastOrNull()?.text ?: "Hello", personality)
        }

        // Construct chat log
        val contents = chatHistory.takeLast(10).map { msg ->
            val role = if (msg.sender == "user") "user" else "model"
            Content(parts = listOf(Part(text = msg.text)))
        }

        val systemPrompt = when (personality) {
            "Brutal" -> "You are Sassy, Sassy Max's brutal lookmaxxing coach. You are hilariously blunt, sarcastic, and extremely honest. No hand-holding. If their jawline is weak, tell them. If their hair is dry, roast them styling-wise. Be extremely brief, entertaining, and always end with an actionable looksmaxxing rule."
            "Friendly" -> "You are Sassy, Sassy Max's friendly and supportive aesthetic advisor. You are warm, encouraging, positive, and give gentle skincare, style, and habit advice. Keep it motivational and focused on positive transformation."
            else -> "You are Sassy, Sassy Max's bold, sassy looksmaxxing coach. You speak like a stylish gen-Z fashion diva, with lots of confidence, sass, and aesthetic jargon (mewing, canthal tilt, hunter eyes, skincare routine, glow-up). Keep answers short, punchy, bold, sassy, and incredibly encouraging!"
        }

        val request = GenerateContentRequest(
            contents = contents.map { it }, // Retrofit requires List of Content
            generationConfig = GenerationConfig(temperature = 0.7f),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
        )

        try {
            val responseBody = apiService.generateContent(apiKey, request)
            val jsonString = responseBody.string()
            val parsedText = parseRawTextResponse(jsonString)
            if (!parsedText.isNullOrBlank()) {
                return@withContext parsedText
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini Chat Error: ${e.message}", e)
        }

        return@withContext getSimulatedSassyResponse(chatHistory.lastOrNull()?.text ?: "", personality)
    }

    private fun parseRawTextResponse(jsonString: String): String? {
        try {
            val responseMap = moshi.adapter(Map::class.java).fromJson(jsonString) ?: return null
            val candidates = responseMap["candidates"] as? List<*> ?: return null
            val firstCandidate = candidates.firstOrNull() as? Map<*, *> ?: return null
            val content = firstCandidate["content"] as? Map<*, *> ?: return null
            val parts = content["parts"] as? List<*> ?: return null
            val firstPart = parts.firstOrNull() as? Map<*, *> ?: return null
            return firstPart["text"] as? String
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing chat response: ${e.message}")
        }
        return null
    }

    private fun getSimulatedSassyResponse(userQuery: String, personality: String): String {
        val query = userQuery.lowercase()
        return when (personality) {
            "Brutal" -> {
                when {
                    query.contains("mew") || query.contains("jaw") -> "Mewing? Honey, mewing won't save you if you're eating sodium-bombs before bed. Put down the chips, drink some water, and chew some mastic gum. Period."
                    query.contains("acne") || query.contains("skin") -> "Your skincare routine is probably non-existent. Soap and water is not a routine, sweetie. Get a salicylic cleanser and SPF immediately, or stay dull."
                    query.contains("hair") -> "That haircut is doing you no favors. It's giving 2012 indie band. Ask your barber for a mid-taper textured fringe and use rosemary oil, please."
                    else -> "Honesty is my brand. Let's fix that style posture first. If you want results, you've got to put in the actual work! What habit are we checking off today?"
                }
            }
            "Friendly" -> {
                when {
                    query.contains("mew") || query.contains("jaw") -> "Mewing is a great way to improve tongue posture over time! Just remember to keep your tongue flat against the roof of your mouth gently. You're doing amazing!"
                    query.contains("acne") || query.contains("skin") -> "Aw, skin glow-ups take some patience! Focus on washing your face twice a day and staying hydrated. Moisturizer is your best friend!"
                    query.contains("hair") -> "Your hair has so much potential! Trying a high-quality nourishing hair oil can really help bring out that rich natural texture and volume!"
                    else -> "You have incredible features and so much natural potential! Let's focus on building small, positive grooming habits together. What shall we work on today?"
                }
            }
            else -> { // Sassy (Default)
                when {
                    query.contains("mew") || query.contains("jaw") -> "Uh, mewing is literally a full-time job! Tongue flat, teeth aligned, no mouth-breathing. We are chiseling that jawline into a diamond, darling!"
                    query.contains("acne") || query.contains("skin") -> "Oh honey, that skin is crying for some hyaluronic hydration! Ditch the face wipes, apply that SPF 50 daily, and let's get that glassy glow!"
                    query.contains("hair") -> "Slay! Your hair needs a textured revamp. Ditch the heat tools, start using a satin pillowcase to avoid breakage, and massage your scalp with rosemary oil."
                    else -> "Oh, you want the Sassy Max secrets? It's simple: stay hydrated, maintain tongue posture, and keep that posture high! Let's get this glow-up moving!"
                }
            }
        }
    }
}
