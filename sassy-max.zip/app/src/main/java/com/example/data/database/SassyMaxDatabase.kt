package com.example.data.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.models.AnalysisResult
import com.example.data.models.ChatMessage
import com.example.data.models.Habit
import com.example.data.models.ProgressPoint
import com.example.data.models.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface SassyMaxDao {
    // --- Profile Queries ---
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfile)

    @Query("DELETE FROM user_profile")
    suspend fun clearUserProfile()

    // --- Chat Queries ---
    @Query("SELECT * FROM chat_message ORDER BY timestamp ASC")
    fun getChatMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessage)

    @Query("DELETE FROM chat_message")
    suspend fun clearChatHistory()

    // --- Analysis Queries ---
    @Query("SELECT * FROM analysis_result ORDER BY id DESC")
    fun getAllAnalysisResults(): Flow<List<AnalysisResult>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysisResult(result: AnalysisResult)

    @Query("DELETE FROM analysis_result")
    suspend fun clearAnalysisResults()

    // --- Habit Queries ---
    @Query("SELECT * FROM habit")
    fun getAllHabits(): Flow<List<Habit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: Habit)

    @Query("UPDATE habit SET isCompletedToday = :completed, streakCount = :streak WHERE id = :id")
    suspend fun updateHabitStatus(id: Long, completed: Boolean, streak: Int)

    @Query("DELETE FROM habit")
    suspend fun clearHabits()

    // --- Progress Queries ---
    @Query("SELECT * FROM progress_history ORDER BY id ASC")
    fun getProgressPoints(): Flow<List<ProgressPoint>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgressPoint(point: ProgressPoint)
}

@Database(
    entities = [
        UserProfile::class,
        ChatMessage::class,
        AnalysisResult::class,
        Habit::class,
        ProgressPoint::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SassyMaxDatabase : RoomDatabase() {
    abstract fun dao(): SassyMaxDao

    companion object {
        @Volatile
        private var INSTANCE: SassyMaxDatabase? = null

        fun getDatabase(context: Context): SassyMaxDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SassyMaxDatabase::class.java,
                    "sassy_max_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
