package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.with
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AnalysisScreen
import com.example.ui.screens.CoachChatScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SassyMaxViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0D0D0F)
                ) {
                    SassyMaxApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalAnimationApi::class)
@Composable
fun SassyMaxApp() {
    val viewModel: SassyMaxViewModel = viewModel()
    val userProfile by viewModel.userProfile.collectAsState()
    val activeTab by viewModel.activeTab.collectAsState()

    val darkBg = Color(0xFF0D0D0F)
    val hotPink = Color(0xFFFF2D6F)
    val cardBg = Color(0xFF1A1A1D)

    // Onboarding Login check
    if (userProfile == null || !userProfile!!.isLoggedIn) {
        LoginScreen(viewModel = viewModel)
        return
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = cardBg,
                modifier = Modifier.fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "Sassy Max",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = hotPink
                    )
                    Text(
                        text = "Aesthetic Vault & Coaching",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.5f)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // Drawer Items matching Sassy Max tabs
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                        label = { Text("Look Analysis") },
                        selected = activeTab == "analysis",
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = hotPink.copy(alpha = 0.15f),
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            unselectedContainerColor = Color.Transparent,
                            unselectedIconColor = Color.White.copy(alpha = 0.6f),
                            unselectedTextColor = Color.White.copy(alpha = 0.8f)
                        ),
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.setTab("analysis")
                        },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.ChatBubble, contentDescription = null) },
                        label = { Text("Coach Chat") },
                        selected = activeTab == "chat",
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = hotPink.copy(alpha = 0.15f),
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            unselectedContainerColor = Color.Transparent,
                            unselectedIconColor = Color.White.copy(alpha = 0.6f),
                            unselectedTextColor = Color.White.copy(alpha = 0.8f)
                        ),
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.setTab("chat")
                        },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                        label = { Text("Progress & Habits") },
                        selected = activeTab == "progress",
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = hotPink.copy(alpha = 0.15f),
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            unselectedContainerColor = Color.Transparent,
                            unselectedIconColor = Color.White.copy(alpha = 0.6f),
                            unselectedTextColor = Color.White.copy(alpha = 0.8f)
                        ),
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.setTab("progress")
                        },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Profile & Settings") },
                        selected = activeTab == "settings",
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = hotPink.copy(alpha = 0.15f),
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            unselectedContainerColor = Color.Transparent,
                            unselectedIconColor = Color.White.copy(alpha = 0.6f),
                            unselectedTextColor = Color.White.copy(alpha = 0.8f)
                        ),
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.setTab("settings")
                        },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = "V1.2.0 (Premium Prototype)",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = darkBg,
            topBar = {
                // Sassy Max Centralized Top Bar with the critical Hamburger Icon ("3 lines on top of app")
                TopAppBar(
                    title = {
                        Text(
                            text = "Sassy Max",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    },
                    navigationIcon = {
                        // The requested "3 lines on top of app" hamburger trigger!
                        IconButton(
                            onClick = {
                                scope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            modifier = Modifier.testTag("hamburger_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu Drawer",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = darkBg,
                        titleContentColor = Color.White
                    ),
                    modifier = Modifier.statusBarsPadding()
                )
            },
            bottomBar = {
                // Custom visually appealing Bottom Navigation bar respecting modern inset styles
                NavigationBar(
                    containerColor = cardBg,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Analysis") },
                        label = { Text("Analysis", fontSize = 10.sp) },
                        selected = activeTab == "analysis",
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            indicatorColor = hotPink.copy(alpha = 0.12f),
                            unselectedIconColor = Color.White.copy(alpha = 0.4f),
                            unselectedTextColor = Color.White.copy(alpha = 0.4f)
                        ),
                        onClick = { viewModel.setTab("analysis") }
                    )

                    NavigationBarItem(
                        icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chat") },
                        label = { Text("AI Coach", fontSize = 10.sp) },
                        selected = activeTab == "chat",
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            indicatorColor = hotPink.copy(alpha = 0.12f),
                            unselectedIconColor = Color.White.copy(alpha = 0.4f),
                            unselectedTextColor = Color.White.copy(alpha = 0.4f)
                        ),
                        onClick = { viewModel.setTab("chat") }
                    )

                    NavigationBarItem(
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Progress") },
                        label = { Text("Progress", fontSize = 10.sp) },
                        selected = activeTab == "progress",
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            indicatorColor = hotPink.copy(alpha = 0.12f),
                            unselectedIconColor = Color.White.copy(alpha = 0.4f),
                            unselectedTextColor = Color.White.copy(alpha = 0.4f)
                        ),
                        onClick = { viewModel.setTab("progress") }
                    )

                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 10.sp) },
                        selected = activeTab == "settings",
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = hotPink,
                            selectedTextColor = hotPink,
                            indicatorColor = hotPink.copy(alpha = 0.12f),
                            unselectedIconColor = Color.White.copy(alpha = 0.4f),
                            unselectedTextColor = Color.White.copy(alpha = 0.4f)
                        ),
                        onClick = { viewModel.setTab("settings") }
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(darkBg)
                    .padding(paddingValues)
            ) {
                AnimatedContent(
                    targetState = activeTab,
                    transitionSpec = {
                        fadeIn() with fadeOut()
                    }
                ) { tab ->
                    when (tab) {
                        "analysis" -> AnalysisScreen(viewModel = viewModel)
                        "chat" -> CoachChatScreen(viewModel = viewModel)
                        "progress" -> ProgressScreen(viewModel = viewModel)
                        "settings" -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
