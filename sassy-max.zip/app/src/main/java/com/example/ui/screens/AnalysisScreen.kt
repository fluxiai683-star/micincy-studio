package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.data.models.AnalysisResult
import com.example.ui.viewmodel.SassyMaxViewModel
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalysisScreen(
    viewModel: SassyMaxViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
    val analysisList by viewModel.analysisResults.collectAsState()

    val currentResult = analysisList.firstOrNull()

    val isUnder18 = (userProfile?.age ?: 22) < 18

    // Styling constants
    val darkBg = Color(0xFF0D0D0F)
    val hotPink = Color(0xFFFF2D6F)
    val mintGreen = Color(0xFF2ECC71)
    val cardBg = Color(0xFF1A1A1D)
    val saveRed = Color(0xFFF14444)

    // Image Picker launcher
    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val bitmap = loadUriAsBitmap(context, it)
            if (bitmap != null) {
                viewModel.analyzeLooks(bitmap, it.toString())
            } else {
                Toast.makeText(context, "Could not load image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Camera Capture launcher for real user selfie
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let {
            viewModel.analyzeLooks(it, "camera")
        }
    }

    var selectedMetricName by remember { mutableStateOf<String?>(null) }
    var showShareSheet by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = darkBg,
        topBar = {
            // HEADER
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(darkBg)
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            // Reset current state or log out
                            viewModel.setTab("chat")
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "GET YOUR ANALYSIS",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )

                    IconButton(
                        onClick = {
                            if (currentResult != null) {
                                showShareSheet = true
                            } else {
                                Toast.makeText(context, "Perform a scan to share your glow-up!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = Color.White
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.05f))
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(darkBg)
                .padding(innerPadding)
        ) {
            when {
                isAnalyzing -> {
                    // Scanning Animation Screen
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = hotPink, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "COMPUTING FACIAL ANGLES...",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Chiseling your Sassy Max scores...",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }

                currentResult == null -> {
                    // LANDING SCREEN - No Scan Yet
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = "Aesthetics",
                            tint = hotPink,
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Analyze Your Looks",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Upload a portrait photo to analyze potential, jawline definition, skincare ratings, cheekbones alignment, and hair style quality.",
                            fontSize = 14.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        // Actions
                        Button(
                            onClick = { cameraLauncher.launch(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = hotPink),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("camera_photo_button")
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Take Selfie with Camera", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { pickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = cardBg),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .border(1.2.dp, Brush.linearGradient(colors = listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.05f))), RoundedCornerShape(16.dp))
                                .testTag("upload_photo_button")
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = mintGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upload from Gallery", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Secondary action for demo testing
                        Text(
                            text = "Or, try our Premium Demo Selfie for instant analysis",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.5f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Button(
                            onClick = {
                                val options = BitmapFactory.Options().apply { inMutable = true }
                                val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.default_portrait, options)
                                if (bitmap != null) {
                                    viewModel.analyzeLooks(bitmap, "demo")
                                } else {
                                    Toast.makeText(context, "Demo asset loading failed", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF1C40F), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Try Premium Demo", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White.copy(alpha = 0.8f))
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Estimate provided by Sassy Max AI. Not scientific diagnostic facts.",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.4f),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                isUnder18 -> {
                    // CONFIDENCE & STYLE TIPS FOR UNDER 18
                    Under18StyleTipsScreen(
                        currentResult = currentResult,
                        hotPink = hotPink,
                        cardBg = cardBg,
                        saveRed = saveRed,
                        onReset = { viewModel.clearAllData() }
                    )
                }

                else -> {
                    // FULL PIXEL MATCHED SCORE SPEC FOR AGES >= 18
                    val genderLabel = when (userProfile?.gender) {
                        "Male" -> "Masculinity"
                        "Female" -> "Femininity"
                        else -> "Facial Balance"
                    }

                    val genderEmoji = when (userProfile?.gender) {
                        "Male" -> "🧑"
                        "Female" -> "🧑"
                        else -> "🧑"
                    }

                    val metrics = listOf(
                        "Potential" to currentResult.potential,
                        genderLabel to currentResult.facialBalance,
                        "Skin" to currentResult.skin,
                        "Jawline" to currentResult.jawline,
                        "Cheekbones" to currentResult.cheekbones,
                        "Hair" to currentResult.hair,
                        "Nose" to currentResult.nose,
                        "Eyes" to currentResult.eyes,
                        "Lips" to currentResult.lips
                    )
                    val lowestMetric = metrics.minByOrNull { it.second }
                    val tipText = if (lowestMetric != null) {
                        "Tap to see how to fix your ${lowestMetric.first} score"
                    } else {
                        "Tap to see how to improve your overall aesthetic"
                    }
                    val lowestMetricKey = when (lowestMetric?.first) {
                        "Potential" -> "potential"
                        genderLabel -> "facialBalance"
                        "Skin" -> "skin"
                        "Jawline" -> "jawline"
                        "Cheekbones" -> "cheekbones"
                        "Hair" -> "hair"
                        "Nose" -> "nose"
                        "Eyes" -> "eyes"
                        "Lips" -> "lips"
                        else -> "potential"
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // AI Disclaimer Header
                        Text(
                            text = "⚠️ AI Style Estimate — Not Scientific Fact",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // HERO SECTION
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left: Uploaded selfie (rounded corner square thumbnail)
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        2.dp,
                                        Brush.linearGradient(
                                            colors = listOf(
                                                hotPink.copy(alpha = 0.8f),
                                                Color.White.copy(alpha = 0.1f)
                                            )
                                        ),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .background(cardBg)
                            ) {
                                if (currentResult.imagePath == "demo") {
                                    Image(
                                        painter = painterResource(id = R.drawable.default_portrait),
                                        contentDescription = "User photo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else if (!currentResult.imagePath.isNullOrBlank()) {
                                    Image(
                                        painter = rememberAsyncImagePainter(model = Uri.parse(currentResult.imagePath)),
                                        contentDescription = "User photo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Image(
                                        painter = painterResource(id = R.drawable.default_portrait),
                                        contentDescription = "Placeholder",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }

                                // Delete icon in top right
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.7f))
                                        .clickable {
                                            viewModel.deleteCurrentResult()
                                            Toast.makeText(context, "Photo removed successfully", Toast.LENGTH_SHORT).show()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove Photo",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(20.dp))

                            // Right: Verdict & Score
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.Center
                            ) {
                                val verdictText = when {
                                    currentResult.overallScore >= 9.0 -> "Exceptional 🔥"
                                    currentResult.overallScore >= 7.0 -> "Attractive 😍"
                                    currentResult.overallScore >= 5.0 -> "Solid ⚡"
                                    else -> "Room to Grow 🌱"
                                }
                                val score = currentResult.overallScore

                                Text(
                                    text = verdictText.uppercase(),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Black,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    color = hotPink
                                )

                                Text(
                                    text = "AI STYLE ESTIMATE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    letterSpacing = 1.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    color = Color.White.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                                )

                                Row(
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Text(
                                        text = "Score",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = score.toString(),
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Black,
                                        color = mintGreen,
                                        lineHeight = 32.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // METRIC GRID — Exactly 9 cards, 3 cols x 3 rows
                        val row1 = listOf(
                            MetricCardData("🚀", "Potential", currentResult.potential, "potential"),
                            MetricCardData(genderEmoji, genderLabel, currentResult.facialBalance, "facialBalance"),
                            MetricCardData("🔬", "Skin", currentResult.skin, "skin")
                        )

                        val row2 = listOf(
                            MetricCardData("🗿", "Jawline", currentResult.jawline, "jawline"),
                            MetricCardData("💎", "Cheekbones", currentResult.cheekbones, "cheekbones"),
                            MetricCardData("💇", "Hair", currentResult.hair, "hair")
                        )

                        val row3 = listOf(
                            MetricCardData("👃", "Nose", currentResult.nose, "nose"),
                            MetricCardData("👁️", "Eyes", currentResult.eyes, "eyes"),
                            MetricCardData("👄", "Lips", currentResult.lips, "lips")
                        )

                        // Draw GridRows sequentially for pixel perfection
                        listOf(row1, row2, row3).forEach { metricRow ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                metricRow.forEach { item ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(0.85f)
                                    ) {
                                        MetricCard(
                                            data = item,
                                            cardBg = cardBg,
                                            mintGreen = mintGreen,
                                            onClick = { selectedMetricName = item.key }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // AI COACH TIP BANNER
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(cardBg)
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                                .clickable { selectedMetricName = lowestMetricKey }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(hotPink),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("✨", fontSize = 20.sp)
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "AI COACH TIP",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = Color.White.copy(alpha = 0.5f)
                                )
                                Text(
                                    text = tipText,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // SAVE RESULTS BUTTON
                        Button(
                            onClick = {
                                Toast.makeText(context, "💾 Analysis saved to your Aesthetic Vault!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = saveRed),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("save_analysis_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Download",
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SAVE RESULTS",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }

            // Metric Details Dialog / Bottom Sheet
            if (selectedMetricName != null && currentResult != null) {
                MetricDetailBottomSheet(
                    metricKey = selectedMetricName!!,
                    result = currentResult,
                    hotPink = hotPink,
                    cardBg = cardBg,
                    mintGreen = mintGreen,
                    onDismiss = { selectedMetricName = null }
                )
            }

            // Share Dialog Mock
            if (showShareSheet && currentResult != null) {
                ShareMockDialog(
                    result = currentResult,
                    onDismiss = { showShareSheet = false },
                    hotPink = hotPink,
                    cardBg = cardBg
                )
            }
        }
    }
}

// --- Metric Card Component ---
data class MetricCardData(
    val emoji: String,
    val label: String,
    val score: Int,
    val key: String
)

@Composable
fun MetricCard(
    data: MetricCardData,
    cardBg: Color,
    mintGreen: Color,
    onClick: () -> Unit
) {
    // Progress bar color selection
    val barColor = when {
        data.score >= 80 -> mintGreen
        data.score >= 60 -> Color(0xFFF1C40F) // Yellow
        data.score >= 45 -> Color(0xFFF39C12) // Orange
        else -> Color(0xFFF14444) // Red
    }

    // 3D Card Gradient Background
    val cardBgGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF24242B), // Elevated/highlighted top bevel
            Color(0xFF141418)  // Sunken dark base
        )
    )

    // Luminous chamfer / 3D edge glow
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.18f),
            Color.White.copy(alpha = 0.03f),
            barColor.copy(alpha = 0.4f)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(cardBgGradient)
            .border(width = 1.2.dp, brush = borderBrush, shape = RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top: Emoji + Label
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = data.emoji, fontSize = 11.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = data.label,
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.7f),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Middle: Big Number
        Text(
            text = data.score.toString(),
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            modifier = Modifier.padding(vertical = 2.dp)
        )

        // Bottom: Progress bar (Neon Glow Style)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(100.dp))
                .background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.CenterStart
        ) {
            // Under-layer blur / halo
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(data.score / 100f)
                    .clip(RoundedCornerShape(100.dp))
                    .background(barColor.copy(alpha = 0.5f))
            )
            // Luminous glowing core
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(data.score / 100f)
                    .clip(RoundedCornerShape(100.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                barColor,
                                Color.White.copy(alpha = 0.95f),
                                barColor
                            )
                        )
                    )
            )
        }
    }
}

// --- Metric Details Modal Bottom Sheet ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetricDetailBottomSheet(
    metricKey: String,
    result: AnalysisResult,
    hotPink: Color,
    cardBg: Color,
    mintGreen: Color,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    // Parse specific metric why/fixes
    var whyStr = "Slight symmetry variation. Excellent potential definition."
    var fixesList = listOf("Perform symmetric chewing exercises", "Stay highly hydrated daily")

    try {
        val adapter = moshi.adapter(Map::class.java)
        val fullMap = adapter.fromJson(result.detailsJson)
        val metricMap = fullMap?.get(metricKey) as? Map<*, *>
        if (metricMap != null) {
            whyStr = metricMap["why"] as? String ?: whyStr
            fixesList = (metricMap["fixes"] as? List<*>)?.mapNotNull { it as? String } ?: fixesList
        }
    } catch (e: Exception) {
        // fallback to standard
    }

    val readableTitle = metricKey.replaceFirstChar { it.uppercase() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = cardBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 48.dp)
        ) {
            Text(
                text = "$readableTitle Insights",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = hotPink
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 1: Why
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = mintGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "COACH DIAGNOSIS",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.4f),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = whyStr,
                        fontSize = 14.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: Concrete Action Items
            Text(
                text = "CONCRETE IMPROVEMENT ACTIONS",
                fontSize = 12.sp,
                color = hotPink,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            fixesList.forEachIndexed { index, fix ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(hotPink.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (index + 1).toString(),
                            color = hotPink,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = fix,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// --- Share Modal Dialog Mock ---
@Composable
fun ShareMockDialog(
    result: AnalysisResult,
    onDismiss: () -> Unit,
    hotPink: Color,
    cardBg: Color
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(cardBg)
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Share Your Slay!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = hotPink
            )
            Spacer(modifier = Modifier.height(8.dp))
            val verdictDesc = when {
                result.overallScore >= 9.0 -> "Exceptional 🔥"
                result.overallScore >= 7.0 -> "Attractive 😍"
                result.overallScore >= 5.0 -> "Solid ⚡"
                else -> "Room to Grow 🌱"
            }
            Text(
                text = "Show your friends that Sassy Max rated you a solid ${result.overallScore} ($verdictDesc)!",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("WhatsApp", "Instagram", "Snapchat", "Copy Link").forEach { platform ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            onDismiss()
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (platform) {
                                    "WhatsApp" -> "🟢"
                                    "Instagram" -> "🌸"
                                    "Snapchat" -> "💛"
                                    else -> "🔗"
                                },
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = platform, color = Color.White, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel", color = Color.White.copy(alpha = 0.5f))
            }
        }
    }
}

// --- Under 18 General Style/Confidence Tips ---
@Composable
fun Under18StyleTipsScreen(
    currentResult: AnalysisResult,
    hotPink: Color,
    cardBg: Color,
    saveRed: Color,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Large Trophy or Star Icon
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(hotPink.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text("✨", fontSize = 48.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Confidence & Style Hub",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = Color.White
        )

        Text(
            text = "Welcome to Sassy Max's safe style center! We skipped numbers because you're growing and already beautiful. Focus on these powerful confidence & style tips:",
            fontSize = 14.sp,
            color = Color.White.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        val tips = listOf(
            "💧 Hydration is Key: Drinking water flushes out sodium, giving your face a naturally clear and energetic look.",
            "☀️ Sunscreen Shield: UV rays damage skin elastin. Wear SPF 30 every single day to stay glassy and protected.",
            "🚶 Stand Tall: Dynamic posture instantly changes how clothes sit and how attractive you feel. Shoulders back, chest up!",
            "💇 Maintain your Hair: Wash with sulfate-free shampoo, massage your scalp, and find a hairstyle that matches your oval shape.",
            "🦷 Floss & Smile: Good dental hygiene is the single most powerful asset. Smile with pride and own the room!"
        )

        tips.forEach { tip ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = tip.substring(0, 2),
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = tip.substring(2),
                        fontSize = 14.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onReset,
            colors = ButtonDefaults.buttonColors(containerColor = saveRed),
            shape = RoundedCornerShape(100.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Guide Offline", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

// Helper to convert Image Uri to Bitmap
fun loadUriAsBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source)
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
