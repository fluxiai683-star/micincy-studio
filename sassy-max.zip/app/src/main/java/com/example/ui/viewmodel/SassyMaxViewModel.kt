package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiClient
import com.example.data.api.SassyAnalysisResult
import com.example.data.database.SassyMaxDatabase
import com.example.data.models.AnalysisResult
import com.example.data.models.ChatMessage
import com.example.data.models.Habit
import com.example.data.models.ProgressPoint
import com.example.data.models.UserProfile
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SassyMaxViewModel(application: Application) : AndroidViewModel(application) {
    private val db = SassyMaxDatabase.getDatabase(application)
    private val dao = db.dao()
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    // --- Exposed Database Flows ---
    val userProfile: StateFlow<UserProfile?> = dao.getUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val messages: StateFlow<List<ChatMessage>> = dao.getChatMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val analysisResults: StateFlow<List<AnalysisResult>> = dao.getAllAnalysisResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habits: StateFlow<List<Habit>> = dao.getAllHabits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val progressPoints: StateFlow<List<ProgressPoint>> = dao.getProgressPoints()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- UI/Operation States ---
    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _chatInput = MutableStateFlow("")
    val chatInput: StateFlow<String> = _chatInput.asStateFlow()

    private val _isSendingMessage = MutableStateFlow(false)
    val isSendingMessage: StateFlow<Boolean> = _isSendingMessage.asStateFlow()

    private val _activeTab = MutableStateFlow("analysis") // "analysis", "chat", "progress", "settings"
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    init {
        // Initialize basic lookmaxxing habits if empty
        viewModelScope.launch {
            val existingHabits = habits.firstOrNull() ?: emptyList()
            if (existingHabits.isEmpty()) {
                dao.insertHabit(Habit(name = "Mewing (Tongue Posture)", category = "Face"))
                dao.insertHabit(Habit(name = "Hydrate with 3L Water", category = "Lifestyle"))
                dao.insertHabit(Habit(name = "Apply daily SPF 30+ Moisturizer", category = "Skin"))
                dao.insertHabit(Habit(name = "Rosemary Scalp Massage", category = "Hair"))
                dao.insertHabit(Habit(name = "Posture & Neck stretches", category = "Lifestyle"))
            }

            // Insert initial greeting if empty
            val existingMessages = messages.firstOrNull() ?: emptyList()
            if (existingMessages.isEmpty()) {
                dao.insertChatMessage(
                    ChatMessage(
                        sender = "coach",
                        text = "Hey babe! I'm Sassy, your premium aesthetic coach. Time to stop scrolling, stand tall, and chisle those features. Upload a photo in the analysis tab or check off your daily habits, and let's get you chiseled! ✨"
                    )
                )
            }
        }
    }

    // --- Onboarding / Login Actions ---
    fun login(name: String, age: Int, gender: String, type: String) {
        viewModelScope.launch {
            val profile = UserProfile(
                name = if (name.trim().isEmpty()) "Guest Max" else name,
                age = age,
                gender = gender,
                isLoggedIn = true,
                loginType = type
            )
            dao.saveUserProfile(profile)
        }
    }

    fun logout() {
        viewModelScope.launch {
            dao.clearUserProfile()
            dao.clearChatHistory()
            dao.clearAnalysisResults()
            dao.clearHabits()
        }
    }

    fun setTab(tab: String) {
        _activeTab.value = tab
    }

    fun updateProfile(name: String, age: Int, gender: String, personality: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile()
            dao.saveUserProfile(
                current.copy(
                    name = name,
                    age = age,
                    gender = gender,
                    coachPersonality = personality
                )
            )
        }
    }

    // --- Look Analysis Logic ---
    fun analyzeLooks(bitmap: Bitmap, imageUriPath: String?) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            try {
                // Call Gemini to analyze
                val rawResult: SassyAnalysisResult = GeminiClient.analyzeLooks(bitmap)

                // Convert explanation object to JSON string using Moshi
                val adapter = moshi.adapter(Map::class.java)
                val explanationsMap = rawResult.explanation.mapValues { (_, valInfo) ->
                    mapOf("why" to valInfo.why, "fixes" to valInfo.fixes)
                }
                val explanationJson = adapter.toJson(explanationsMap)

                val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())

                val dbResult = AnalysisResult(
                    dateString = dateStr,
                    overallScore = rawResult.overallScore,
                    imagePath = imageUriPath,
                    potential = rawResult.potential,
                    facialBalance = rawResult.facialBalance,
                    skin = rawResult.skin,
                    jawline = rawResult.jawline,
                    cheekbones = rawResult.cheekbones,
                    hair = rawResult.hair,
                    nose = rawResult.nose,
                    eyes = rawResult.eyes,
                    lips = rawResult.lips,
                    detailsJson = explanationJson
                )

                // Save result
                dao.insertAnalysisResult(dbResult)

                // Add to progress points
                dao.insertProgressPoint(
                    ProgressPoint(
                        dateString = dateStr,
                        overallScore = rawResult.overallScore
                    )
                )

                // Inform the chat coach about the new scan!
                val chatMsg = ChatMessage(
                    sender = "coach",
                    text = "Oh honey! I saw your look analysis. Score is ${rawResult.overallScore} (${rawResult.verdictText})! Your ${getLowestScoreMetric(rawResult)} is where we need to focus first. Let's start tracking SPF and face habits immediately! You got this! ✨"
                )
                dao.insertChatMessage(chatMsg)

            } catch (e: Exception) {
                Log.e("ViewModel", "Analysis failed: ${e.message}", e)
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    private fun getLowestScoreMetric(result: SassyAnalysisResult): String {
        val scores = mapOf(
            "facial balance" to result.facialBalance,
            "skin" to result.skin,
            "jawline" to result.jawline,
            "cheekbones" to result.cheekbones,
            "hair" to result.hair,
            "nose" to result.nose,
            "eyes" to result.eyes,
            "lips" to result.lips
        )
        return scores.minByOrNull { it.value }?.key ?: "features"
    }

    // --- Chat Logic ---
    fun updateChatInput(input: String) {
        _chatInput.value = input
    }

    fun sendChatMessage() {
        val text = _chatInput.value.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            _chatInput.value = ""
            _isSendingMessage.value = true

            // Save user message
            val userMsg = ChatMessage(sender = "user", text = text)
            dao.insertChatMessage(userMsg)

            // Fetch chat history for context
            val history = dao.getChatMessages().firstOrNull() ?: emptyList()
            val personality = userProfile.value?.coachPersonality ?: "Sassy"

            // Get coach reply from Gemini
            val replyText = GeminiClient.getSassyCoachResponse(history, personality)

            // Save coach message
            val coachMsg = ChatMessage(sender = "coach", text = replyText)
            dao.insertChatMessage(coachMsg)

            _isSendingMessage.value = false
        }
    }

    // --- Habit Logic ---
    fun toggleHabit(habit: Habit) {
        viewModelScope.launch {
            val newCompleted = !habit.isCompletedToday
            val newStreak = if (newCompleted) habit.streakCount + 1 else maxOf(0, habit.streakCount - 1)
            dao.updateHabitStatus(habit.id, newCompleted, newStreak)
        }
    }

    fun addNewHabit(name: String, category: String) {
        if (name.trim().isEmpty()) return
        viewModelScope.launch {
            dao.insertHabit(Habit(name = name, category = category))
        }
    }

    fun deleteCurrentResult() {
        viewModelScope.launch {
            dao.clearAnalysisResults()
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            dao.clearChatHistory()
            dao.clearAnalysisResults()
            dao.clearUserProfile()
            // Reset habits
            dao.clearHabits()
            dao.insertHabit(Habit(name = "Mewing (Tongue Posture)", category = "Face"))
            dao.insertHabit(Habit(name = "Hydrate with 3L Water", category = "Lifestyle"))
            dao.insertHabit(Habit(name = "Apply daily SPF 30+ Moisturizer", category = "Skin"))
            dao.insertHabit(Habit(name = "Rosemary Scalp Massage", category = "Hair"))
            dao.insertHabit(Habit(name = "Posture & Neck stretches", category = "Lifestyle"))
        }
    }
}
