package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SassyMaxViewModel

@Composable
fun ProgressScreen(
    viewModel: SassyMaxViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val progressPoints by viewModel.progressPoints.collectAsState()
    val habits by viewModel.habits.collectAsState()

    var showAddHabitDialog by remember { mutableStateOf(false) }
    var newHabitName by remember { mutableStateOf("") }
    var newHabitCategory by remember { mutableStateOf("Face") }

    val darkBg = Color(0xFF0D0D0F)
    val hotPink = Color(0xFFFF2D6F)
    val cardBg = Color(0xFF1A1A1D)
    val mintGreen = Color(0xFF2ECC71)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(darkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Chart Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ShowChart,
                contentDescription = null,
                tint = hotPink,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Aesthetic Score Timeline",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // INTUITIVE CANVAS CHART CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(cardBg)
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            if (progressPoints.isEmpty()) {
                // Empty State
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📊", fontSize = 36.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No history points yet.",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Complete your first look scan to start tracking aesthetic progression!",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 4.dp)
                    )
                }
            } else {
                // Beautiful Line Chart drawing using Canvas
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "PROGRESS TRACKER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = hotPink,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Last scan: ${progressPoints.last().overallScore}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = mintGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    ) {
                        val maxScore = 10f
                        val minScore = 0f
                        val sizeWidth = size.width
                        val sizeHeight = size.height

                        // Calculate coords
                        val pointsCount = progressPoints.size
                        val stepX = if (pointsCount > 1) sizeWidth / (pointsCount - 1) else sizeWidth
                        val stepY = sizeHeight / (maxScore - minScore)

                        val path = Path()
                        val fillPath = Path()

                        val coordinates = progressPoints.mapIndexed { index, point ->
                            val score = point.overallScore.toFloat()
                            val x = if (pointsCount > 1) index * stepX else sizeWidth / 2
                            // Invert Y since (0,0) is top-left
                            val y = sizeHeight - (score * stepY)
                            Offset(x, y)
                        }

                        // Build smooth lines
                        coordinates.forEachIndexed { index, offset ->
                            if (index == 0) {
                                path.moveTo(offset.x, offset.y)
                                fillPath.moveTo(offset.x, offset.y)
                            } else {
                                path.lineTo(offset.x, offset.y)
                                fillPath.lineTo(offset.x, offset.y)
                            }
                        }

                        // Close fill path for glowing background
                        if (coordinates.isNotEmpty()) {
                            fillPath.lineTo(coordinates.last().x, sizeHeight)
                            fillPath.lineTo(coordinates.first().x, sizeHeight)
                            fillPath.close()

                            // Draw glowing area
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        hotPink.copy(alpha = 0.25f),
                                        Color.Transparent
                                    )
                                )
                            )

                            // Draw Line
                            drawPath(
                                path = path,
                                color = hotPink,
                                style = Stroke(width = 3.dp.toPx())
                            )

                            // Draw dots
                            coordinates.forEach { offset ->
                                drawCircle(
                                    color = Color.White,
                                    radius = 5.dp.toPx(),
                                    center = offset
                                )
                                drawCircle(
                                    color = hotPink,
                                    radius = 3.dp.toPx(),
                                    center = offset
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Labels below chart
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = progressPoints.first().dateString,
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 10.sp
                        )
                        if (progressPoints.size > 1) {
                            Text(
                                text = progressPoints.last().dateString,
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // HABIT TRACKER HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔥", fontSize = 24.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Aesthetic Daily Habits",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            IconButton(
                onClick = { showAddHabitDialog = true },
                colors = IconButtonDefaults.iconButtonColors(containerColor = hotPink.copy(alpha = 0.15f))
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Habit", tint = hotPink)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // HABITS LIST
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            habits.forEach { habit ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(cardBg)
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                        .clickable { viewModel.toggleHabit(habit) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Checkbox(
                            checked = habit.isCompletedToday,
                            onCheckedChange = { viewModel.toggleHabit(habit) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = mintGreen,
                                uncheckedColor = Color.White.copy(alpha = 0.3f),
                                checkmarkColor = Color.Black
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = habit.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (habit.isCompletedToday) Color.White.copy(alpha = 0.5f) else Color.White
                            )
                            Text(
                                text = "Category: ${habit.category}",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.4f)
                            )
                        }
                    }

                    // Streak Count
                    if (habit.streakCount > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(hotPink.copy(alpha = 0.12f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("🔥", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${habit.streakCount}d",
                                color = hotPink,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // ADD CUSTOM HABIT DIALOG
        if (showAddHabitDialog) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { showAddHabitDialog = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(cardBg)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                        .padding(24.dp)
                ) {
                    Text(
                        text = "Add Custom Habit",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = hotPink
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newHabitName,
                        onValueChange = { newHabitName = it },
                        placeholder = { Text("E.g., Facial Massage, Hair Oil", color = Color.Gray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = hotPink,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_habit_name_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Category",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val categories = listOf("Face", "Skin", "Hair", "Lifestyle")
                        categories.forEach { cat ->
                            val isSelected = newHabitCategory == cat
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) hotPink else Color.Black.copy(alpha = 0.3f))
                                    .clickable { newHabitCategory = cat }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cat,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { showAddHabitDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                        ) {
                            Text("Cancel", color = Color.White.copy(alpha = 0.5f))
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (newHabitName.trim().isNotBlank()) {
                                    viewModel.addNewHabit(newHabitName, newHabitCategory)
                                    newHabitName = ""
                                    showAddHabitDialog = false
                                    Toast.makeText(context, "Habit added!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = hotPink)
                        ) {
                            Text("Add", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
