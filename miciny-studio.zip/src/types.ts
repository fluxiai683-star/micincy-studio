export interface Tool {
  id: string;
  title: string;
  description: string;
  iconName: string;
  downloads: string;
  rating: string;
  tags: string[];
  features: string[];
  playStoreUrl: string;
}

export interface StatItem {
  id: string;
  value: string;
  label: string;
  description: string;
  colorType: 'venom' | 'coral' | 'bone';
}

export interface AboutCard {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  bgColor: string;
  glowColor: string;
}
