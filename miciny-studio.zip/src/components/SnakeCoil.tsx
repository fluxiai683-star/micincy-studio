import React from 'react';
import { motion } from 'motion/react';

interface SnakeCoilProps {
  variant: 'hero-bg' | 'divider-1' | 'divider-2' | 'divider-3';
}

export const SnakeCoil: React.FC<SnakeCoilProps> = ({ variant }) => {
  if (variant === 'hero-bg') {
    // Large intricate neon-green coiled vector that slowly rotates and pulses
    return (
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none select-none z-0">
        {/* Subtle radial backdrop gradient */}
        <div className="absolute w-[600px] h-[600px] rounded-full bg-radial from-venom/5 to-transparent blur-3xl" />
        
        <motion.div
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 45,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="relative w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] opacity-15 md:opacity-25"
        >
          <svg
            width="100%"
            height="100%"
            viewBox="0 0 500 500"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Multi-layered nested coil lines to look complex and 3D */}
            <motion.path
              d="M 250 250
                 M 250 250 C 275 220, 290 180, 270 140
                 C 250 100, 190 100, 170 150
                 C 150 200, 210 260, 250 290
                 C 290 320, 360 310, 380 250
                 C 400 190, 330 110, 250 90
                 C 170 70, 70 160, 90 250
                 C 110 340, 220 430, 330 400
                 C 440 370, 470 230, 400 130
                 C 330 30, 180 20, 90 100"
              stroke="#C6FF3C"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="12 12"
              fill="none"
            />
            
            <path
              d="M 250 250
                 M 250 250 C 225 280, 210 320, 230 360
                 C 250 400, 310 400, 330 350
                 C 350 300, 290 240, 250 210
                 C 210 180, 140 190, 120 250
                 C 100 310, 170 390, 250 410
                 C 330 430, 430 340, 410 250
                 C 390 160, 280 70, 170 100
                 C 60 130, 30 270, 100 370"
              stroke="#FF6B4D"
              strokeWidth="2"
              strokeLinecap="round"
              fill="none"
              opacity="0.6"
            />
            
            <circle cx="250" cy="250" r="10" fill="#C6FF3C" />
          </svg>
        </motion.div>
      </div>
    );
  }

  // Winding horizontal dividers that slither into view
  // Let's create beautiful curved waves with SVG
  let pathD = '';
  let strokeColor = '#C6FF3C';
  let height = '80px';
  
  if (variant === 'divider-1') {
    // Left-to-right slow slither with deep curve
    pathD = 'M -50 40 C 150 10, 250 70, 450 40 C 650 10, 850 70, 1050 40 C 1250 10, 1350 50, 1550 40';
    strokeColor = '#C6FF3C';
  } else if (variant === 'divider-2') {
    // Left-to-right alternating
    pathD = 'M -50 40 C 200 80, 400 0, 600 40 C 800 80, 1000 0, 1200 40 C 1400 80, 1500 20, 1650 40';
    strokeColor = '#FF6B4D'; // Coral accent touch
  } else {
    // Sleek thin divider
    pathD = 'M -50 40 C 100 30, 300 50, 500 40 C 700 30, 900 50, 1100 40 C 1300 30, 1450 50, 1650 40';
    strokeColor = '#C6FF3C';
  }

  return (
    <div className="relative w-full overflow-hidden pointer-events-none select-none my-6 z-10" style={{ height }}>
      <svg
        width="100%"
        height="100%"
        viewBox="0 0 1600 80"
        preserveAspectRatio="none"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="opacity-70"
      >
        {/* Glow path behind */}
        <motion.path
          d={pathD}
          stroke={strokeColor}
          strokeWidth="6"
          strokeLinecap="round"
          fill="none"
          opacity="0.1"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: false, amount: 0.1 }}
          transition={{ duration: 2.2, ease: 'easeInOut' }}
        />
        
        {/* Crisp core slithering path */}
        <motion.path
          d={pathD}
          stroke={strokeColor}
          strokeWidth="2"
          strokeLinecap="round"
          fill="none"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: false, amount: 0.1 }}
          transition={{ duration: 1.8, ease: 'easeInOut' }}
        />

        {/* Small sparkling head indicator that slithers along the path */}
        <motion.circle
          r="4"
          fill="#F3F1EA"
          initial={{ offset: 0 }}
          animate={{
            cx: [100, 1500],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="opacity-50"
        />
      </svg>
    </div>
  );
};
