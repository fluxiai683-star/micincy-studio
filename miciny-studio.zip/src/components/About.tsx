import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Zap, Cpu, Sparkles, Layers, Minimize2 } from 'lucide-react';
import { AboutCard } from '../types';

export const About: React.FC = () => {
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Hardcoded card definitions for the layered 3D app stack
  const cards: AboutCard[] = [
    {
      id: 'apex-shell',
      title: 'APEX TERMINAL',
      subtitle: 'System Controller & ADB Helper',
      iconName: 'Cpu',
      bgColor: 'bg-gradient-to-br from-obsidian via-ink to-emerald-950/30',
      glowColor: 'group-hover:border-venom/30 shadow-[0_0_30px_rgba(198,255,60,0.03)]',
    },
    {
      id: 'aurora-opt',
      title: 'AURA BATTERY',
      subtitle: 'Ultra-low Battery Service',
      iconName: 'Zap',
      bgColor: 'bg-gradient-to-br from-obsidian via-ink to-orange-950/30',
      glowColor: 'group-hover:border-coral/30 shadow-[0_0_30px_rgba(255,107,77,0.03)]',
    },
    {
      id: 'crypt-guard',
      title: 'VENOM SHIELD',
      subtitle: 'Encrypted Folder & App Locker',
      iconName: 'ShieldCheck',
      bgColor: 'bg-gradient-to-br from-obsidian via-ink to-slate-900',
      glowColor: 'group-hover:border-white/20 shadow-[0_0_30px_rgba(255,255,255,0.03)]',
    },
  ];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const { left, top, width, height } = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 2 - 1; // -1 to 1
    const y = ((e.clientY - top) / height) * 2 - 1; // -1 to 1
    
    // Tilt limits
    setRotate({
      x: y * -15, // rotate around X axis (tilt vertical)
      y: x * 15,  // rotate around Y axis (tilt horizontal)
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  // Helper to map icon name to Lucide components
  const renderIcon = (name: string, colorClass: string) => {
    switch (name) {
      case 'Cpu':
        return <Cpu className={colorClass} size={24} />;
      case 'Zap':
        return <Zap className={colorClass} size={24} />;
      case 'ShieldCheck':
      default:
        return <ShieldCheck className={colorClass} size={24} />;
    }
  };

  return (
    <section id="about" className="relative py-24 bg-obsidian text-bone px-4 overflow-hidden">
      {/* Background radial soft orange highlight to mirror the SaaS dashboard energy */}
      <div className="absolute top-1/2 right-10 w-[400px] h-[400px] bg-coral/2 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-[300px] h-[300px] bg-venom/2 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Column: Mission Description */}
          <div className="lg:col-span-6 flex flex-col items-start">
            {/* Tag label */}
            <div className="flex items-center gap-2 mb-4 font-mono text-[10px] tracking-widest text-venom uppercase">
              <Layers size={12} />
              <span>STUDIO MANIFESTO</span>
            </div>

            {/* Title with Space Grotesk */}
            <h2 className="font-display font-black text-3xl sm:text-4xl text-bone tracking-tight leading-tight uppercase mb-6">
              WE BUILD TOOLS WITH <br />
              <span className="text-venom italic text-glow-venom">ZERO COMPROMISE</span>
            </h2>

            {/* Paragraphs with Inter */}
            <div className="space-y-5 font-sans text-muted-gray text-base leading-relaxed font-light">
              <p>
                At Miciny Studio, we believe mobile apps should be like surgical scalpels: 
                <strong className="text-bone font-medium"> ultra-sharp, specialized, and instantaneous</strong>. 
                We design with clean layouts, optimized background payloads, and zero ad bloat.
              </p>
              <p>
                Our philosophy centers around <span className="text-bone">utility optimization</span>. 
                We analyze key operational gaps within the standard Google Play catalog, 
                and engineer compact, fast-running Android solutions that strike the gap perfectly.
              </p>
              <p>
                Every tool we ship features a custom, lightweight kernel wrapper, native 
                material layout standards, and direct developer options. We don't build platforms; 
                we build high-speed utilities that work beautifully, first time, every time.
              </p>
            </div>

            {/* Three distinct value cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8 w-full">
              <div className="p-4 bg-ink/40 border border-white/5 rounded-xl flex items-start gap-3">
                <div className="p-2 rounded-lg bg-venom/10 text-venom mt-1 shrink-0">
                  <Zap size={16} />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-sm text-bone uppercase">STRIKING SPEED</h3>
                  <p className="font-mono text-[11px] text-muted-gray mt-1">Cold boot in under 120ms. Zero-latency UI loops.</p>
                </div>
              </div>

              <div className="p-4 bg-ink/40 border border-white/5 rounded-xl flex items-start gap-3">
                <div className="p-2 rounded-lg bg-coral/10 text-coral mt-1 shrink-0">
                  <Minimize2 size={16} />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-sm text-bone uppercase">COMPACT BUILD</h3>
                  <p className="font-mono text-[11px] text-muted-gray mt-1">Under 8MB average APK package footprint.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Layered 3D tilting App Card stack */}
          <div className="lg:col-span-6 flex justify-center items-center py-8">
            <div
              ref={containerRef}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={handleMouseLeave}
              className="relative w-[300px] h-[380px] sm:w-[350px] sm:h-[420px] cursor-pointer flex items-center justify-center"
              style={{ perspective: 1200 }}
            >
              {/* Active tilting boundary card container */}
              <div
                className="relative w-full h-full flex items-center justify-center transition-all duration-300 ease-out"
                style={{
                  transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg)`,
                  transformStyle: 'preserve-3d',
                }}
              >
                {/* 3 App Cards Layered on top of each other with different translates in Z axis */}
                {cards.map((card, idx) => {
                  // Custom transforms per card index to create depth layering
                  const zTranslate = idx * 30; // 0, 30, 60
                  const scaleFactor = 1 - (2 - idx) * 0.05; // 0.9, 0.95, 1
                  const topOffset = idx * -25; // Stack effect
                  const leftOffset = idx * 10;

                  return (
                    <div
                      key={card.id}
                      className={`absolute w-[260px] h-[300px] sm:w-[290px] sm:h-[340px] rounded-2xl p-6 border border-white/10 ${card.bgColor} ${card.glowColor} flex flex-col justify-between backdrop-blur-sm transition-all duration-300`}
                      style={{
                        transform: `translate3d(${leftOffset}px, ${topOffset}px, ${zTranslate}px) scale(${scaleFactor})`,
                        zIndex: idx + 1,
                        transformStyle: 'preserve-3d',
                      }}
                    >
                      {/* Card Header metadata */}
                      <div className="flex items-center justify-between" style={{ transform: 'translateZ(20px)' }}>
                        <span className="font-mono text-[9px] text-muted-gray uppercase tracking-widest">
                          MICINY APPS // #{idx + 1}
                        </span>
                        <span className="w-1.5 h-1.5 rounded-full bg-venom" />
                      </div>

                      {/* Card Center: App Logo Symbol */}
                      <div className="flex flex-col items-center justify-center my-4" style={{ transform: 'translateZ(40px)' }}>
                        <div className="p-4 bg-obsidian border border-white/5 rounded-2xl mb-3 shadow-inner group-hover:border-white/15">
                          {renderIcon(card.iconName, idx === 0 ? 'text-venom' : idx === 1 ? 'text-coral' : 'text-bone')}
                        </div>
                        <h4 className="font-display font-bold text-base tracking-wider text-bone mt-2">
                          {card.title}
                        </h4>
                        <span className="font-sans text-[11px] text-muted-gray text-center mt-1">
                          {card.subtitle}
                        </span>
                      </div>

                      {/* Card Footer: Dev labels */}
                      <div className="flex items-center justify-between mt-auto border-t border-white/5 pt-4" style={{ transform: 'translateZ(10px)' }}>
                        <span className="font-mono text-[9px] text-venom">
                          SYS_STABLE
                        </span>
                        <div className="flex gap-1">
                          <span className="w-4 h-1 rounded-full bg-white/20" />
                          <span className="w-2 h-1 rounded-full bg-white/20" />
                          <span className="w-1 h-1 rounded-full bg-venom" />
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Perspective helper badge */}
                <div 
                  className="absolute bottom-2 font-mono text-[9px] text-muted-gray tracking-wider flex items-center gap-1.5 opacity-60 hover:opacity-100 transition-opacity"
                  style={{ transform: 'translateZ(80px)' }}
                >
                  <Sparkles size={10} className="text-venom" />
                  <span>3D STACK LAYER VIEW</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
