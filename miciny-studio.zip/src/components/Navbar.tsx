import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SnakeLogo } from './SnakeLogo';
import { Menu, X, Mail, Play } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      // Simple active section detection based on current scroll position
      const sections = ['hero', 'about', 'builds', 'stats', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 120 && rect.bottom >= 120) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'hero', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'builds', label: 'Tools' },
    { id: 'stats', label: 'Impact' },
    { id: 'contact', label: 'Contact' },
  ];

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-4 sm:px-6 py-4 ${
          isScrolled 
            ? 'bg-obsidian/80 backdrop-blur-md border-b border-white/5 py-3' 
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Brand Logo & Wordmark */}
          <button
            onClick={() => scrollToSection('hero')}
            className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-venom/50 rounded-lg p-1 text-left"
            aria-label="Miciny Studio Home"
            id="nav-logo"
          >
            <div className="relative p-1.5 bg-white rounded-md transition-transform duration-300 group-hover:scale-105">
              <SnakeLogo size={32} accentColor="bone" glow={false} />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-bone tracking-[0.3em] text-lg leading-none">
                MICINY
              </span>
              <span className="font-mono text-[9px] text-venom tracking-wider mt-0.5">
                STUDIO
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 bg-ink/40 border border-white/5 p-1 rounded-full backdrop-blur-sm">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`relative px-4 py-1.5 text-xs font-mono tracking-wider uppercase rounded-full transition-colors duration-300 focus:outline-none focus:ring-1 focus:ring-venom/30 ${
                    isActive ? 'text-venom' : 'text-muted-gray hover:text-bone'
                  }`}
                  id={`nav-link-${item.id}`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="activeNavBackground"
                      className="absolute inset-0 bg-ink border border-white/10 rounded-full z-0"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Desktop Action Button */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="mailto:micinystudio@gmail.com"
              className="flex items-center gap-2 bg-venom hover:bg-[#b5f02b] text-obsidian px-4 py-2 rounded-lg font-mono text-xs font-bold tracking-wider uppercase transition-all duration-300 hover:shadow-[0_0_15px_rgba(198,255,60,0.4)] focus:outline-none focus:ring-2 focus:ring-venom/50"
              id="desktop-cta"
            >
              <Mail size={14} />
              <span>Strike First</span>
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-bone hover:text-venom focus:outline-none focus:ring-2 focus:ring-venom/50 rounded-lg"
            aria-label="Toggle Navigation Menu"
            id="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </motion.header>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-0 top-[65px] bg-obsidian border-b border-white/10 z-40 p-6 md:hidden flex flex-col gap-6 shadow-2xl backdrop-blur-lg"
          >
            <div className="flex flex-col gap-3">
              {navItems.map((item, index) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all font-mono text-sm uppercase tracking-wider ${
                      isActive 
                        ? 'bg-ink border-venom/30 text-venom font-semibold' 
                        : 'bg-ink/30 border-transparent text-muted-gray hover:text-bone hover:bg-ink/50'
                    }`}
                    id={`mobile-nav-link-${item.id}`}
                  >
                    <span>{item.label}</span>
                    <Play size={12} className={isActive ? 'text-venom animate-pulse' : 'text-muted-gray/40'} />
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col gap-3 border-t border-white/5 pt-5">
              <p className="font-mono text-[10px] text-muted-gray uppercase tracking-widest text-center">
                Let's Build Something Awesome
              </p>
              <a
                href="mailto:micinystudio@gmail.com"
                className="flex items-center justify-center gap-2 bg-venom text-obsidian py-3 rounded-xl font-mono text-xs font-bold tracking-wider uppercase transition-colors hover:bg-[#b5f02b]"
              >
                <Mail size={16} />
                <span>micinystudio@gmail.com</span>
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
