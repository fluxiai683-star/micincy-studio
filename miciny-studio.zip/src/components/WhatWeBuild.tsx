import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tool } from '../types';
import { 
  Globe, 
  Cpu, 
  Terminal, 
  Volume2, 
  Star, 
  ArrowUpRight, 
  Download, 
  Layers, 
  Flame,
  CheckCircle2,
  X
} from 'lucide-react';

export const WhatWeBuild: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);

  // High-fidelity mobile tool definitions
  const tools: Tool[] = [
    {
      id: 'apex-dns',
      title: 'Apex DNS Tuner',
      description: 'Zero-overhead mobile DNS injector that reduces ping jitter and secures connection queries without root access.',
      iconName: 'Globe',
      downloads: '50K+',
      rating: '4.8',
      tags: ['Network', 'No-Root', 'No-Ads'],
      features: [
        'Over 18 premium built-in secure DNS providers (Cloudflare, Google, AdGuard)',
        'Local DNS caching layer to speed up domain lookups',
        'Automatic protocol fallback (DoH / DoT / DNSCrypt)',
        'Extremely friendly to system battery life (0% background overhead)'
      ],
      playStoreUrl: 'https://play.google.com/store'
    },
    {
      id: 'venom-kernel',
      title: 'Venom Optimizer',
      description: 'Compact background task terminator and memory governor engineered to prevent terminal thermal throttling.',
      iconName: 'Cpu',
      downloads: '80K+',
      rating: '4.9',
      tags: ['System', 'Battery', 'Utility'],
      features: [
        'Single-tap background memory scavenger',
        'Intelligent CPU thermal warning scheduler',
        'Automatic profile selector (Gaming, Daily, Battery saver)',
        'Hardware spec monitor with micro-graph updates'
      ],
      playStoreUrl: 'https://play.google.com/store'
    },
    {
      id: 'core-adb',
      title: 'Core ADB Shell',
      description: 'Sleek, wireless terminal interface for executing ADB shell commands directly from your local Android console.',
      iconName: 'Terminal',
      downloads: '40K+',
      rating: '4.7',
      tags: ['Power-User', 'ADB', 'Shell'],
      features: [
        'Pre-loaded shorthand commands for system config adjustment',
        'Full color-coded terminal theme and command history support',
        'Direct local storage port connection guides',
        'Fast system telemetry and service state querying'
      ],
      playStoreUrl: 'https://play.google.com/store'
    },
    {
      id: 'spectra-synth',
      title: 'Spectra Audio',
      description: 'Real-time focus synthesizer and binaural noise cancellation generator to shield your workspace environment.',
      iconName: 'Volume2',
      downloads: '20K+',
      rating: '4.8',
      tags: ['Ambient', 'Audio', 'Focus'],
      features: [
        'Slick interactive audio frequency spectrum slider',
        'Scientific 432Hz tuning preset modes',
        'Offline background player (works perfectly inside airplanes)',
        'High-contrast material dark widgets for immediate playback'
      ],
      playStoreUrl: 'https://play.google.com/store'
    }
  ];

  const renderIcon = (name: string, className: string) => {
    switch (name) {
      case 'Globe':
        return <Globe className={className} size={28} />;
      case 'Cpu':
        return <Cpu className={className} size={28} />;
      case 'Terminal':
        return <Terminal className={className} size={28} />;
      case 'Volume2':
      default:
        return <Volume2 className={className} size={28} />;
    }
  };

  return (
    <section id="builds" className="relative py-24 bg-obsidian text-bone px-4 overflow-hidden">
      {/* Background radial glows */}
      <div className="absolute top-1/4 left-10 w-[300px] h-[300px] bg-venom/3 rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-[300px] h-[300px] bg-coral/3 rounded-full blur-[110px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="flex flex-col items-start">
            <div className="flex items-center gap-2 mb-4 font-mono text-[10px] tracking-widest text-venom uppercase">
              <Flame size={12} className="animate-pulse text-venom" />
              <span>LAUNCH CATALOG</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-4xl text-bone tracking-tight leading-tight uppercase">
              TOOLS ENGINEERED <br />
              FOR <span className="text-venom italic text-glow-venom">THE PLAY STORE</span>
            </h2>
          </div>
          <p className="font-sans text-muted-gray text-sm md:text-base max-w-md leading-relaxed font-light">
            We identify high-value developer utilities and optimize them down to the bare bone: 
            ad-free core, lightweight packaging, and pristine material interfaces.
          </p>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {tools.map((tool) => (
            <TiltCard key={tool.id} tool={tool} renderIcon={renderIcon} onSelect={setSelectedTool} />
          ))}
        </div>
      </div>

      {/* Modal Popup for Details */}
      <AnimatePresence>
        {selectedTool && (
          <div className="fixed inset-0 bg-obsidian/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="bg-ink border border-white/10 rounded-2xl p-6 sm:p-8 max-w-2xl w-full relative max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedTool(null)}
                className="absolute top-4 right-4 p-2 text-muted-gray hover:text-bone focus:outline-none focus:ring-2 focus:ring-venom/50 rounded-lg cursor-pointer"
                aria-label="Close details dialog"
              >
                <X size={20} />
              </button>

              {/* Title & Category Info */}
              <div className="flex items-start gap-4 mb-6">
                <div className="p-3 bg-obsidian border border-white/5 rounded-xl text-venom">
                  {renderIcon(selectedTool.iconName, 'text-venom')}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="font-mono text-[9px] text-venom bg-venom/10 border border-venom/20 px-2 py-0.5 rounded">
                      ACTIVE VERSION
                    </span>
                    <div className="flex items-center gap-1 text-[11px] font-mono text-muted-gray">
                      <Star size={10} className="text-coral fill-current" />
                      <span>{selectedTool.rating} App Rating</span>
                    </div>
                  </div>
                  <h3 className="font-display font-bold text-2xl text-bone uppercase">
                    {selectedTool.title}
                  </h3>
                </div>
              </div>

              {/* Brief Description */}
              <p className="font-sans text-muted-gray text-sm leading-relaxed mb-6 font-light">
                {selectedTool.description}
              </p>

              {/* Features List */}
              <div className="mb-8">
                <h4 className="font-display font-semibold text-xs text-bone tracking-wider uppercase mb-3 border-b border-white/5 pb-2">
                  KEY FEATURES
                </h4>
                <ul className="space-y-2.5">
                  {selectedTool.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-xs font-sans text-muted-gray leading-relaxed">
                      <CheckCircle2 size={14} className="text-venom shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Downloads Bar & Play Store Action */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-obsidian/50 border border-white/5 p-4 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-white/5 text-bone">
                    <Download size={16} />
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-muted-gray uppercase block">GO PLAY DOWNLOADS</span>
                    <span className="font-display font-bold text-bone text-base">{selectedTool.downloads} Installs</span>
                  </div>
                </div>

                <a
                  href={selectedTool.playStoreUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-venom hover:bg-[#b5f02b] text-obsidian px-5 py-3 rounded-xl font-mono text-xs font-bold tracking-wider uppercase w-full sm:w-auto transition-all"
                >
                  <span>Strike Play Store</span>
                  <ArrowUpRight size={14} />
                </a>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

/* Individual Card Component to contain isolation of mouse handlers for 3D tilt */
interface TiltCardProps {
  tool: Tool;
  renderIcon: (name: string, className: string) => React.ReactNode;
  onSelect: (tool: Tool) => void;
}

const TiltCard: React.FC<TiltCardProps> = ({ tool, renderIcon, onSelect }) => {
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const { left, top, width, height } = cardRef.current.getBoundingClientRect();
    
    // Calculate values from -1 to 1
    const x = ((e.clientX - left) / width) * 2 - 1;
    const y = ((e.clientY - top) / height) * 2 - 1;

    setRotate({
      x: y * -10, // vertical tilt rotation
      y: x * 10,  // horizontal tilt rotation
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      onClick={() => onSelect(tool)}
      className="relative group cursor-pointer focus:outline-none"
      style={{ perspective: 800 }}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onSelect(tool);
        }
      }}
      aria-label={`View details for ${tool.title}`}
    >
      {/* Outer 3D bounding card */}
      <div
        className="w-full bg-ink/50 border border-white/5 rounded-2xl p-6 transition-all duration-300 flex flex-col justify-between min-h-[220px] shadow-lg group-hover:border-venom/20 group-hover:glow-venom group-hover:bg-ink/70"
        style={{
          transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg)`,
          transition: isHovered ? 'none' : 'transform 0.4s ease-out',
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Top bar with icon and meta rating */}
        <div className="flex items-start justify-between" style={{ transform: 'translateZ(15px)' }}>
          <div className="p-3 bg-obsidian border border-white/5 rounded-xl text-muted-gray group-hover:text-venom transition-colors duration-300">
            {renderIcon(tool.iconName, 'transition-transform duration-500 group-hover:scale-110')}
          </div>
          
          <div className="flex items-center gap-3 font-mono text-[11px]">
            <div className="flex items-center gap-1 text-coral">
              <Star size={11} className="fill-current" />
              <span>{tool.rating}</span>
            </div>
            <div className="w-1 h-1 bg-white/20 rounded-full" />
            <div className="text-muted-gray flex items-center gap-1">
              <Download size={11} />
              <span>{tool.downloads}</span>
            </div>
          </div>
        </div>

        {/* Info Block */}
        <div className="my-6" style={{ transform: 'translateZ(25px)' }}>
          <h3 className="font-display font-bold text-lg tracking-wider text-bone group-hover:text-venom transition-colors uppercase">
            {tool.title}
          </h3>
          <p className="font-sans text-muted-gray text-xs sm:text-sm leading-relaxed mt-2 font-light line-clamp-2">
            {tool.description}
          </p>
        </div>

        {/* Footer info/tags */}
        <div className="flex items-center justify-between border-t border-white/5 pt-4 mt-auto" style={{ transform: 'translateZ(10px)' }}>
          <div className="flex flex-wrap gap-1.5">
            {tool.tags.map((tag) => (
              <span 
                key={tag}
                className="font-mono text-[8px] sm:text-[9px] uppercase tracking-wider bg-obsidian text-muted-gray border border-white/5 px-2 py-0.5 rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>

          <div className="w-7 h-7 rounded-lg bg-obsidian/80 border border-white/5 flex items-center justify-center text-muted-gray group-hover:text-venom group-hover:border-venom/30 transition-all duration-300">
            <ArrowUpRight size={14} className="transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
        </div>
      </div>
    </div>
  );
};
