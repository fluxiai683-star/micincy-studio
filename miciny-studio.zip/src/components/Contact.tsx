import React from 'react';
import { motion } from 'motion/react';
import { SnakeLogo } from './SnakeLogo';
import { Mail, ArrowUpRight, Github, Twitter, ShieldCheck, Cpu } from 'lucide-react';

export const Contact: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const handleScrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="contact" className="relative bg-obsidian text-bone pt-20 pb-12 px-4 overflow-hidden border-t border-white/5">
      {/* Background soft lighting */}
      <div className="absolute bottom-0 inset-x-0 h-[300px] bg-gradient-to-t from-venom/3 to-transparent pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Call to Action Container Widget */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative bg-ink/50 border border-white/10 rounded-3xl p-8 sm:p-12 md:p-16 text-center overflow-hidden mb-20"
        >
          {/* Internal diagonal accent stripes */}
          <div className="absolute inset-0 bg-radial from-venom/5 to-transparent blur-3xl pointer-events-none" />

          {/* Core Winding Snake Divider overlay inside card */}
          <div className="absolute inset-x-0 bottom-0 overflow-hidden h-[40px] opacity-20 pointer-events-none">
            <svg width="100%" height="100%" viewBox="0 0 1000 40" preserveAspectRatio="none" fill="none">
              <path d="M 0 20 C 100 0, 200 40, 300 20 C 400 0, 500 40, 600 20 C 700 0, 800 40, 900 20 C 1000 0, 1100 20, 1200 20" stroke="#C6FF3C" strokeWidth="2" />
            </svg>
          </div>

          <div className="max-w-2xl mx-auto relative z-10 flex flex-col items-center">
            {/* Custom visual logo crown above CTA */}
            <div className="p-3 bg-white rounded-2xl mb-8 transition-transform duration-300 hover:rotate-12 hover:scale-105">
              <SnakeLogo size={44} accentColor="bone" glow={false} />
            </div>

            <span className="font-mono text-xs text-venom font-medium tracking-[0.2em] uppercase mb-4">
              LAUNCH COLLABORATION // STRIKE THE MARKET
            </span>

            <h2 className="font-display font-black text-3xl sm:text-4xl md:text-5xl text-bone tracking-tight uppercase mb-6 leading-tight">
              HAVE A TOOL IDEA? <br />
              LET'S <span className="text-venom italic text-glow-venom">STRIKE</span> TOGETHER.
            </h2>

            <p className="font-sans text-muted-gray text-sm sm:text-base max-w-lg mb-8 leading-relaxed font-light">
              Whether you are an Android engineer looking to publish, a distributor, 
              or a mobile user seeking custom software, we are ready to respond.
            </p>

            {/* Huge mail button */}
            <a
              href="mailto:micinystudio@gmail.com"
              className="group inline-flex items-center justify-center gap-3 bg-venom hover:bg-[#b5f02b] text-obsidian font-mono text-sm font-bold tracking-wider uppercase px-8 py-5 rounded-2xl w-full sm:w-auto transition-all duration-300 hover:shadow-[0_0_35px_rgba(198,255,60,0.6)] focus:outline-none focus:ring-4 focus:ring-venom/40"
              id="cta-mail-button"
            >
              <Mail size={18} className="transition-transform group-hover:scale-110" />
              <span>micinystudio@gmail.com</span>
              <ArrowUpRight size={16} className="transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>
        </motion.div>

        {/* Minimalist Footer Grid */}
        <footer className="border-t border-white/5 pt-12 flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Logo & copyright */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <button
              onClick={() => handleScrollTo('hero')}
              className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-venom/50 rounded-lg p-1 text-left"
              aria-label="Scroll to top"
            >
              <div className="p-1 bg-white rounded-md">
                <SnakeLogo size={24} accentColor="bone" />
              </div>
              <span className="font-display font-bold text-bone tracking-[0.3em] text-sm">
                MICINY
              </span>
            </button>
            
            <p className="font-sans text-muted-gray text-xs mt-3 font-light">
              © {currentYear} Miciny Studio. All rights reserved.
            </p>
            <p className="font-mono text-[9px] text-muted-gray/50 mt-1">
              BUILD_REF: F0_SNAK_PROD_1.2
            </p>
          </div>

          {/* Quick links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-mono text-muted-gray">
            <button 
              onClick={() => handleScrollTo('hero')} 
              className="hover:text-venom transition-colors focus:outline-none focus:ring-1 focus:ring-venom/50 px-2 py-1 rounded"
              id="footer-link-home"
            >
              HOME
            </button>
            <button 
              onClick={() => handleScrollTo('about')} 
              className="hover:text-venom transition-colors focus:outline-none focus:ring-1 focus:ring-venom/50 px-2 py-1 rounded"
              id="footer-link-about"
            >
              ABOUT
            </button>
            <button 
              onClick={() => handleScrollTo('builds')} 
              className="hover:text-venom transition-colors focus:outline-none focus:ring-1 focus:ring-venom/50 px-2 py-1 rounded"
              id="footer-link-builds"
            >
              TOOLS
            </button>
            <button 
              onClick={() => handleScrollTo('stats')} 
              className="hover:text-venom transition-colors focus:outline-none focus:ring-1 focus:ring-venom/50 px-2 py-1 rounded"
              id="footer-link-stats"
            >
              IMPACT
            </button>
          </div>

          {/* Social icons */}
          <div className="flex items-center gap-3">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 bg-ink border border-white/5 hover:border-venom/20 rounded-lg text-muted-gray hover:text-venom transition-all focus:outline-none focus:ring-2 focus:ring-venom/50"
              aria-label="Miciny Studio GitHub profile"
            >
              <Github size={16} />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 bg-ink border border-white/5 hover:border-venom/20 rounded-lg text-muted-gray hover:text-venom transition-all focus:outline-none focus:ring-2 focus:ring-venom/50"
              aria-label="Miciny Studio Twitter profile"
            >
              <Twitter size={16} />
            </a>
            <a
              href="https://play.google.com/store"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 bg-ink border border-white/5 hover:border-venom/20 rounded-lg text-muted-gray hover:text-venom transition-all font-mono text-[10px] tracking-wider focus:outline-none focus:ring-2 focus:ring-venom/50"
              aria-label="Miciny Studio Play Store Developer Console link"
            >
              <Cpu size={12} />
              <span>PLAY CONSOLE</span>
            </a>
          </div>

        </footer>
      </div>
    </section>
  );
};
