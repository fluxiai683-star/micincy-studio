import React from 'react';

interface SnakeLogoProps {
  className?: string;
  size?: number;
  glow?: boolean;
  accentColor?: 'venom' | 'coral' | 'bone';
  showWordmark?: boolean;
}

export const SnakeLogo: React.FC<SnakeLogoProps> = ({
  className = '',
  size = 64,
  glow = false,
  accentColor = 'venom',
  showWordmark = false,
}) => {
  // Color configuration based on theme
  const getColors = () => {
    switch (accentColor) {
      case 'venom':
        return {
          stroke: '#C6FF3C',
          glowColor: 'rgba(198, 255, 60, 0.4)',
          gradientStart: '#C6FF3C',
          gradientEnd: '#8AFF3C',
        };
      case 'coral':
        return {
          stroke: '#FF6B4D',
          glowColor: 'rgba(255, 107, 77, 0.4)',
          gradientStart: '#FF6B4D',
          gradientEnd: '#FF3D14',
        };
      case 'bone':
      default:
        return {
          stroke: '#F3F1EA',
          glowColor: 'rgba(243, 241, 234, 0.2)',
          gradientStart: '#F3F1EA',
          gradientEnd: '#C3C1BA',
        };
    }
  };

  const colors = getColors();

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{
          filter: glow ? `drop-shadow(0 0 12px ${colors.glowColor})` : 'none',
          transition: 'all 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="transform hover:scale-105"
      >
        <defs>
          <linearGradient id={`snake-grad-${accentColor}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={colors.gradientStart} />
            <stop offset="100%" stopColor={colors.gradientEnd} />
          </linearGradient>
        </defs>

        {/* Outer subtle glow circle */}
        {glow && (
          <circle
            cx="100"
            cy="100"
            r="85"
            stroke={colors.stroke}
            strokeWidth="1"
            strokeOpacity="0.15"
            strokeDasharray="4 4"
            className="animate-spin"
            style={{ animationDuration: '30s' }}
          />
        )}

        {/* Elegant Coiled S-Serpent - High-quality Vector Paths matching the reference logo */}
        <g transform="translate(10, 10) scale(0.9)">
          {/* Main Coiled Snake Body Path */}
          <path
            d="M 100 20 
               C 125 20, 150 35, 145 60 
               C 140 85, 95 95, 80 110 
               C 65 125, 60 145, 90 160 
               C 120 175, 145 165, 150 140
               C 152 130, 145 125, 138 128
               C 130 132, 125 148, 100 150
               C 85 152, 75 142, 82 130
               C 89 118, 115 105, 130 90
               C 155 65, 150 40, 120 28
               C 105 22, 90 25, 100 20 Z"
            fill={`url(#snake-grad-${accentColor})`}
            fillRule="evenodd"
          />

          {/* Detailed Head Overlay (Sleek contours and eye) */}
          <path
            d="M 125 45 
               C 138 38, 148 42, 155 40
               C 162 38, 168 45, 172 48
               C 175 50, 170 54, 162 55
               C 154 56, 142 55, 130 50 Z"
            fill={`url(#snake-grad-${accentColor})`}
          />

          {/* Striking Tongue */}
          <path
            d="M 166 51 
               C 174 52, 178 48, 184 49
               M 178 49 
               C 181 44, 185 42, 188 41"
            stroke={colors.stroke}
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Sharp Crown/Tail element at the bottom to form the coiled base */}
          <path
            d="M 75 145
               C 60 155, 55 120, 45 95
               C 42 88, 48 85, 52 92
               C 60 108, 65 125, 75 145 Z"
            fill={`url(#snake-grad-${accentColor})`}
          />

          {/* Serpent Eye (cutout) */}
          <path
            d="M 148 44 
               C 152 44, 155 46, 158 45
               C 155 47, 151 47, 148 44 Z"
            fill="#0B0C0F"
          />
        </g>
      </svg>

      {showWordmark && (
        <span
          className="mt-4 font-display font-bold text-bone tracking-[0.4em] text-center"
          style={{
            fontSize: `${size * 0.28}px`,
            marginLeft: '0.4em', // offset the last trailing tracking space
          }}
        >
          MICINY
        </span>
      )}
    </div>
  );
};
