import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { SnakeLogo } from './SnakeLogo';
import { ArrowDown, Flame, Play, ShieldCheck } from 'lucide-react';

export const Hero: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle subtle mouse parallax movement
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const { left, top, width, height } = containerRef.current.getBoundingClientRect();
      // Calculate normalized position from -1 to 1
      const x = ((e.clientX - left) / width) * 2 - 1;
      const y = ((e.clientY - top) / height) * 2 - 1;
      setMousePosition({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  // Parallax layers factor
  const logoParallax = {
    x: mousePosition.x * 25,
    y: mousePosition.y * 25,
    rotateX: mousePosition.y * -15,
    rotateY: mousePosition.x * 15,
  };

  const bgParticles = [
    { id: 1, top: '20%', left: '15%', size: 4, speed: 0.05 },
    { id: 2, top: '15%', left: '75%', size: 6, speed: -0.07 },
    { id: 3, top: '65%', left: '10%', size: 8, speed: 0.03 },
    { id: 4, top: '75%', left: '85%', size: 5, speed: -0.04 },
    { id: 5, top: '40%', left: '80%', size: 3, speed: 0.08 },
  ];

  const handleScrollDown = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      ref={containerRef}
      className="relative min-h-screen flex flex-col justify-center items-center bg-obsidian text-bone pt-24 pb-16 px-4 overflow-hidden"
      style={{ perspective: 1000 }}
    >
      {/* Background radial highlight glow */}
      <div className="absolute inset-0 bg-radial from-[#15171C]/60 via-obsidian to-obsidian pointer-events-none" />

      {/* Floating subtle ambient lights */}
      <div className="absolute top-1/4 left-1/4 w-[350px] h-[350px] bg-venom/3 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[350px] h-[350px] bg-coral/3 rounded-full blur-[120px] pointer-events-none" />

      {/* Mouse Parallax Vector Particles */}
      {bgParticles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-white/20 pointer-events-none"
          style={{
            top: particle.top,
            left: particle.left,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            transform: `translate3d(${mousePosition.x * particle.speed * 200}px, ${mousePosition.y * particle.speed * 200}px, 0)`,
            transition: 'transform 0.15s ease-out',
            boxShadow: particle.id === 2 ? '0 0 8px rgba(198, 255, 60, 0.4)' : 'none',
          }}
        />
      ))}

      {/* Hero Content Grid - Structured, premium balance of negative space */}
      <div className="relative max-w-5xl w-full grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center z-10">
        
        {/* Left column: Wordmark, taglines, description & CTAs */}
        <div className="md:col-span-7 flex flex-col text-center md:text-left items-center md:items-start order-2 md:order-1">
          {/* Eyebrow Label with modern developer tag style */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="inline-block px-3 py-1 border border-venom/30 bg-ink/20 rounded-full mb-6"
          >
            <span className="text-[10px] font-mono tracking-[0.3em] text-venom uppercase font-medium">
              V.02 Android Strike Division
            </span>
          </motion.div>

          {/* Main Title Heading with bold geometric Space Grotesk font */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut' }}
            className="font-display font-black text-5xl sm:text-6xl md:text-7xl leading-[0.95] tracking-tight uppercase mb-6"
          >
            BUILDING TOOLS <br />
            THAT <span className="text-venom italic text-glow-venom">STRIKE</span> FIRST.
          </motion.h1>

          {/* Description Body Copy using Inter with clean line height */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
            className="font-sans text-muted-gray text-base sm:text-lg max-w-lg mb-8 leading-relaxed font-light"
          >
            We are <strong className="text-bone font-medium">Miciny Studio</strong>. 
            A precise, fast-moving software house crafting high-performance, single-purpose 
            Android applications and developer utilities that dominate the Play Store ecosystem.
          </motion.p>

          {/* Interactive CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
            className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
          >
            <button
              onClick={() => document.getElementById('builds')?.scrollIntoView({ behavior: 'smooth' })}
              className="group flex items-center justify-center gap-2 bg-venom text-obsidian font-mono text-xs font-bold tracking-wider uppercase px-6 py-4 rounded-xl w-full sm:w-auto transition-all duration-300 hover:shadow-[0_0_25px_rgba(198,255,60,0.5)] hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-venom/50"
            >
              <Play size={14} className="fill-current" />
              <span>Explore Tools</span>
            </button>

            <button
              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
              className="flex items-center justify-center gap-2 bg-ink hover:bg-ink/80 text-bone border border-white/5 font-mono text-xs tracking-wider uppercase px-6 py-4 rounded-xl w-full sm:w-auto transition-all hover:border-white/20 focus:outline-none focus:ring-2 focus:ring-white/20"
            >
              <span>Our Philosophy</span>
            </button>
          </motion.div>

          {/* Secondary stats/assurance tag in Mono */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="flex items-center gap-6 mt-12 border-t border-white/5 pt-6 w-full justify-center md:justify-start text-xs font-mono text-muted-gray"
          >
            <div className="flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-venom" />
              <span>Ad-Free Utility Focus</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Flame size={14} className="text-coral" />
              <span>Lightweight builds</span>
            </div>
          </motion.div>
        </div>

        {/* Right column: Interactive 3D floating coiled serpent */}
        <div className="md:col-span-5 flex justify-center order-1 md:order-2">
          <motion.div
            initial={{ scale: 0.8, opacity: 0, rotate: -20 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
            className="relative cursor-pointer select-none group"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => {
              setIsHovered(false);
            }}
            style={{
              transform: `translate3d(${logoParallax.x}px, ${logoParallax.y}px, 0) rotateX(${logoParallax.rotateX}px) rotateY(${logoParallax.rotateY}px)`,
              transition: isHovered ? 'none' : 'transform 0.5s ease-out',
              transformStyle: 'preserve-3d',
            }}
          >
            {/* Ambient neon radial green glow behind the 3D logo */}
            <div 
              className={`absolute inset-0 bg-venom/10 rounded-full blur-[60px] transition-all duration-700 pointer-events-none ${
                isHovered ? 'scale-125 opacity-100 blur-[80px]' : 'scale-100 opacity-60'
              }`} 
            />

            {/* Main Outer Decorative Circle */}
            <div className="relative w-[280px] h-[280px] sm:w-[360px] sm:h-[360px] rounded-full bg-ink/60 border border-white/10 flex items-center justify-center p-8 backdrop-blur-md shadow-2xl transition-all duration-500 group-hover:border-venom/20 group-hover:shadow-[0_0_50px_rgba(198,255,60,0.15)]">
              {/* Spinning technical coordinate lines */}
              <div 
                className="absolute inset-2 border border-dashed border-white/5 rounded-full animate-spin pointer-events-none" 
                style={{ animationDuration: '60s' }}
              />
              
              <div 
                className="absolute inset-8 border border-white/5 rounded-full animate-spin pointer-events-none" 
                style={{ animationDuration: '45s', animationDirection: 'reverse' }}
              />

              {/* The Serpent Logo Render */}
              <div style={{ transform: 'translateZ(40px)', transformStyle: 'preserve-3d' }}>
                <SnakeLogo
                  size={200}
                  accentColor="venom"
                  glow={true}
                  showWordmark={true}
                />
              </div>

              {/* Monospace calibration tags around the logo for dev vibe */}
              <span className="absolute top-4 left-4 font-mono text-[9px] text-muted-gray tracking-wider">
                SYS_VER_2.6
              </span>
              <span className="absolute bottom-4 right-4 font-mono text-[9px] text-venom tracking-wider">
                STRYKE_ACTV
              </span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Scroll Cue */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        onClick={handleScrollDown}
        className="absolute bottom-8 flex flex-col items-center gap-2 text-muted-gray hover:text-venom transition-colors focus:outline-none focus:ring-1 focus:ring-venom/30 rounded-lg p-1.5 cursor-pointer group"
        aria-label="Scroll down to About section"
      >
        <span className="font-mono text-[9px] tracking-widest uppercase">SWIPE DOWN</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
        >
          <ArrowDown size={14} className="group-hover:text-venom" />
        </motion.div>
      </motion.button>
    </section>
  );
};
