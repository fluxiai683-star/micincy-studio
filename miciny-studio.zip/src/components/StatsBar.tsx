import React from 'react';
import { motion } from 'motion/react';
import { StatItem } from '../types';
import { Sparkles, Users, Award, ShieldAlert } from 'lucide-react';

export const StatsBar: React.FC = () => {
  const stats: StatItem[] = [
    {
      id: 'shipped',
      value: '15+',
      label: 'TOOLS SHIPPED',
      description: 'Single-purpose fast Android tools',
      colorType: 'venom',
    },
    {
      id: 'downloads',
      value: '190K+',
      label: 'TOTAL DOWNLOADS',
      description: 'Active Play Store installations',
      colorType: 'coral',
    },
    {
      id: 'users',
      value: '190+',
      label: 'STABLE REVIEWS',
      description: 'High average 4.8★ app rating',
      colorType: 'bone',
    },
  ];

  const getGlowStyle = (type: 'venom' | 'coral' | 'bone') => {
    switch (type) {
      case 'venom':
        return 'from-venom/10 to-transparent';
      case 'coral':
        return 'from-coral/10 to-transparent';
      case 'bone':
      default:
        return 'from-bone/10 to-transparent';
    }
  };

  const getIcon = (id: string, colorType: 'venom' | 'coral' | 'bone') => {
    const cls = colorType === 'venom' ? 'text-venom' : colorType === 'coral' ? 'text-coral' : 'text-bone';
    switch (id) {
      case 'shipped':
        return <Award className={cls} size={20} />;
      case 'downloads':
        return <Sparkles className={cls} size={20} />;
      case 'users':
      default:
        return <Users className={cls} size={20} />;
    }
  };

  return (
    <section id="stats" className="relative py-20 bg-obsidian text-bone px-4 overflow-hidden border-t border-b border-white/5">
      {/* Background radial soft light */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#15171C]/10 via-obsidian to-[#15171C]/10 pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Metric Grid with SaaS widget containers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6, delay: idx * 0.15, ease: 'easeOut' }}
              className="relative overflow-hidden bg-ink/30 border border-white/5 rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 hover:border-white/10 hover:bg-ink/50 group"
            >
              {/* Radial gradient background light - responsive scaling */}
              <div 
                className={`absolute -right-16 -top-16 w-44 h-44 rounded-full bg-radial ${getGlowStyle(stat.colorType)} blur-[35px] opacity-40 group-hover:scale-125 transition-transform duration-500 pointer-events-none`} 
              />

              {/* Header metrics card line */}
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 bg-obsidian border border-white/5 rounded-xl">
                  {getIcon(stat.id, stat.colorType)}
                </div>
                <span className="font-mono text-[9px] text-muted-gray uppercase tracking-widest">
                  TELEMETRY_DAT // 0{idx + 1}
                </span>
              </div>

              {/* Number and description layout */}
              <div>
                <h3 className="font-display font-bold text-4xl sm:text-5xl text-bone tracking-tight uppercase leading-none mb-2">
                  {stat.value}
                </h3>
                
                <h4 className="font-mono text-xs text-venom font-medium tracking-widest uppercase mb-1">
                  {stat.label}
                </h4>
                
                <p className="font-sans text-muted-gray text-xs leading-relaxed font-light mt-2">
                  {stat.description}
                </p>
              </div>

              {/* Subtle visual connector line in dashboard cards */}
              <div className="w-full h-[1px] bg-white/5 mt-6 relative overflow-hidden">
                <div 
                  className={`absolute left-0 top-0 h-full w-12 bg-gradient-to-r ${
                    stat.colorType === 'venom' ? 'from-venom' : stat.colorType === 'coral' ? 'from-coral' : 'from-bone'
                  } to-transparent animate-shimmer`}
                  style={{
                    animation: 'shimmer 3s infinite linear',
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Small warning disclaimer about system telemetry in dev theme */}
        <div className="flex items-center justify-center gap-2 mt-8 text-[10px] font-mono text-muted-gray tracking-wider uppercase opacity-40">
          <ShieldAlert size={11} className="text-coral" />
          <span>REAL-TIME PLATFORM DATA SYNCHRONIZED WITH GOOGLE CONSOLE</span>
        </div>
      </div>
    </section>
  );
};
