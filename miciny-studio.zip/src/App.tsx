/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { WhatWeBuild } from './components/WhatWeBuild';
import { StatsBar } from './components/StatsBar';
import { Contact } from './components/Contact';
import { SnakeCoil } from './components/SnakeCoil';

export default function App() {
  return (
    <div className="min-h-screen bg-obsidian text-bone selection:bg-venom selection:text-obsidian font-sans antialiased overflow-x-hidden">
      {/* Floating navigation bar */}
      <Navbar />

      {/* Hero section */}
      <div className="relative">
        <SnakeCoil variant="hero-bg" />
        <Hero />
      </div>

      {/* Section Divider 1 */}
      <SnakeCoil variant="divider-1" />

      {/* About section */}
      <About />

      {/* Section Divider 2 */}
      <SnakeCoil variant="divider-2" />

      {/* What We Build (Tools grid) section */}
      <WhatWeBuild />

      {/* SaaS Dashboard Stats bar */}
      <StatsBar />

      {/* Section Divider 3 */}
      <SnakeCoil variant="divider-3" />

      {/* Contact call-to-action & footer */}
      <Contact />
    </div>
  );
}
